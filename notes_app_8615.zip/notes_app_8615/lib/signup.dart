import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:notes_app_8615/login.dart';
import 'package:notes_app_8615/notes_home.dart';


class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  //Creating two boolean variables to determine that the password is visible or not.
  bool _passwordVisible = false;
  bool _confirmVisible = false;
  //Initializing a key for form to uniquely identify and allow validation
  final _formKey = GlobalKey<FormState>();
  //For user sign-up, we will declare instances that will manage and retrieve the text entered into the fields.
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirmPassword = TextEditingController();

  //Also we create a dispose function to dispose the controllers
  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _confirmPassword.dispose();
    super.dispose();
  }

  //Now, we create a '_showDialog' method to display an 'AlertDialog' widget,
  // So, we can display message from the try-catch exception handler
  void _showDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text('Message'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  //Now, we will create an async function for sign-up page,
  //that will submit the users entered data in to the database using functionalities of 'Firebase'.
  void _signUp() async {
    //Now, check that the validation by using '_formKey'.
    if (_formKey.currentState!.validate()) {
      //Now, using try and catch to handle errors and 'Firebase' authentication
      try {
        //Also,
        //Now, we will create a new user with email and password
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _email.text.trim(),
          password: _password.text.trim(),
        );
        //Now, Show a message that the user has successfully signed-up
        //By calling a '_showDialog' method.
        _showDialog('Registered Successfully');

        //Navigate to the next screen
        if(mounted){
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (BuildContext context) => NotesHomeScreen()),
          );
        }
      } on FirebaseAuthException catch (e) {
        //Using 'FirebaseAuthException' to catch errors like 'email-already-in-use' e.t.c
        String errorMessage;
        //check with correct error codes provided by 'Firebase'.
        if (e.code == 'email-already-in-use') {
          errorMessage =
          'This e-mail is already in use. Please try another e-mail';
        } //check if the password is weak
        else if (e.code == 'weak-password') {
          errorMessage =
          'This password is too weak. Please choose a stronger password';
        } else {
          errorMessage = 'An error occurred. Please try again later';
        }
        //Display it by passing 'errorMessage'
        _showDialog(errorMessage);
      } catch (e) {
        _showDialog('An unexpected error occurred');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'Sign-Up Page',
          style: TextStyle(fontSize: 30, color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        //To create a sign-up page, we will use 'Form' widget along with 'TextFormFields'.
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                emailField(),
                SizedBox(height: 15),
                passField(),
                SizedBox(height: 15),
                confirmField(),
                SizedBox(height: 20),
                //Now, creating an 'ElevatedButton' to call the '_signUp' method
                signupButton(),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Already have an account?',
                      style: TextStyle(fontSize: 30, color: Colors.black),
                    ),
                    //Navigate to login page if the user already has an account.
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Login()),
                        );
                      },
                      child: Text(
                        'Login',
                        style:TextStyle(color: Colors.blueAccent, fontSize: 18)
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  ElevatedButton signupButton() {
    return ElevatedButton(
      onPressed: () {
        _signUp();
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.blue,
        elevation: 5,
      ),
      child: Text(
        'Register',
        style: TextStyle(fontSize: 15, color: Colors.white)
      ),
    );
  }

  //I have refactor the email field
  TextFormField emailField() {
    return TextFormField(
      keyboardType: TextInputType.emailAddress,
      controller: _email,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.email_rounded),
        labelText: 'Enter Your E-Mail Address',
        floatingLabelStyle: TextStyle(
          color: Colors.blue, //This is the focused label color
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.grey, width: 2.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.blue, width: 2.0),
        ),
      ),
      cursorColor: Colors.blue,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter E-mail Address';
        }
        if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
          return 'Please enter a valid E-mail Address';
        }
        return null;
      },
    );
  }


  TextFormField passField() {
    return TextFormField(
      controller: _password,
      obscureText: _passwordVisible,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.password_rounded),
        labelText: 'Enter your Password',
        floatingLabelStyle: TextStyle(color: Colors.blue),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.grey),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.blue),
        ),
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              _passwordVisible = !_passwordVisible;
            });
          },
          icon: Icon(
            _passwordVisible ? Icons.visibility_off : Icons.visibility,
          ),
        ),
      ),
      cursorColor: Colors.blue,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your password';
        }
        if (value.length < 6) {
          return 'Password must be at least 6 characters';
        }
        return null;
      },
    );
  }


  TextFormField confirmField() {
    return TextFormField(
      controller: _confirmPassword,
      obscureText: _confirmVisible,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.password_rounded),
        labelText: 'Confirm your Password',
        floatingLabelStyle: TextStyle(color: Colors.blue),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.grey),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.blue),
        ),
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              _confirmVisible = !_confirmVisible;
            });
          },
          icon: Icon(_confirmVisible ? Icons.visibility_off : Icons.visibility),
        ),
      ),
      cursorColor: Colors.blue,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your password';
        }
        if (value != _password.text) {
          return 'Password does not match';
        }
        return null;
      },
    );
  }
}
