import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:notes_app_8615/login.dart';
import 'package:notes_app_8615/notes_home.dart';


class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot){
          if(snapshot.connectionState== ConnectionState.waiting){
            return Center(child:
            CircularProgressIndicator(
              color: Colors.blue,
              strokeWidth: 4,
            ),);
          }else if(snapshot.hasData){
            return NotesHomeScreen();
          }
          else{
            return Login();
          }
        }
    );
  }
}
