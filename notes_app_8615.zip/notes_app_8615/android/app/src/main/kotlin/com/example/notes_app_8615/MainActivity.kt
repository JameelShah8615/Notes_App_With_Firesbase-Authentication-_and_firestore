package com.example.notes_app_8615

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
